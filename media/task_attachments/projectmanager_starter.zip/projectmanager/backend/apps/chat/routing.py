from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    # Project channel: ws://localhost:8000/ws/chat/project/<project_id>/
    re_path(r'ws/chat/(?P<room_type>project)/(?P<room_id>[^/]+)/$', consumers.ChatConsumer.as_asgi()),

    # Private ping: ws://localhost:8000/ws/chat/private/<user_id>/
    re_path(r'ws/chat/(?P<room_type>private)/(?P<room_id>[^/]+)/$', consumers.ChatConsumer.as_asgi()),
]
