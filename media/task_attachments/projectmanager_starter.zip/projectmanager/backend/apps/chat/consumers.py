import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.utils import timezone


class ChatConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for real-time chat.
    Handles both:
      - Project channels:  ws://localhost:8000/ws/chat/project/<project_id>/
      - Private pings:     ws://localhost:8000/ws/chat/private/<user_id>/
    """

    async def connect(self):
        self.room_type = self.scope['url_route']['kwargs'].get('room_type', 'project')
        self.room_id   = self.scope['url_route']['kwargs']['room_id']
        self.user      = self.scope['user']

        if not self.user.is_authenticated:
            await self.close()
            return

        # Group name = unique room identifier in Redis
        self.group_name = f"{self.room_type}_{self.room_id}"

        # Join the channel group
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

        # Mark user as online
        await self.set_user_online(True)

        # Notify others in the room that this user joined
        await self.channel_layer.group_send(self.group_name, {
            'type':    'user_status',
            'user_id': str(self.user.id),
            'name':    self.user.get_full_name() or self.user.email,
            'status':  'online',
        })

    async def disconnect(self, close_code):
        await self.set_user_online(False)

        await self.channel_layer.group_send(self.group_name, {
            'type':    'user_status',
            'user_id': str(self.user.id),
            'name':    self.user.get_full_name() or self.user.email,
            'status':  'offline',
        })

        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def receive(self, text_data):
        """Called when a message is received from the WebSocket client"""
        data    = json.loads(text_data)
        message = data.get('message', '').strip()

        if not message:
            return

        # Save message to DB
        saved = await self.save_message(message)

        # Broadcast to everyone in the group
        await self.channel_layer.group_send(self.group_name, {
            'type':       'chat_message',
            'message_id': str(saved['id']),
            'message':    message,
            'user_id':    str(self.user.id),
            'user_name':  self.user.get_full_name() or self.user.email,
            'timestamp':  saved['timestamp'],
        })

    # ── Event handlers ────────────────────────────────────────

    async def chat_message(self, event):
        """Sends a chat message to the WebSocket"""
        await self.send(text_data=json.dumps({
            'type':       'message',
            'message_id': event['message_id'],
            'message':    event['message'],
            'user_id':    event['user_id'],
            'user_name':  event['user_name'],
            'timestamp':  event['timestamp'],
        }))

    async def user_status(self, event):
        """Sends online/offline status to the WebSocket"""
        await self.send(text_data=json.dumps({
            'type':    'status',
            'user_id': event['user_id'],
            'name':    event['name'],
            'status':  event['status'],
        }))

    # ── DB helpers (run in thread pool) ──────────────────────

    @database_sync_to_async
    def save_message(self, message_text):
        from .models import ChatMessage
        msg = ChatMessage.objects.create(
            room_type  = self.room_type,
            room_id    = self.room_id,
            sender     = self.user,
            content    = message_text,
            sent_at    = timezone.now(),
        )
        return {
            'id':        str(msg.id),
            'timestamp': msg.sent_at.isoformat(),
        }

    @database_sync_to_async
    def set_user_online(self, is_online):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        User.objects.filter(pk=self.user.pk).update(is_online=is_online)
