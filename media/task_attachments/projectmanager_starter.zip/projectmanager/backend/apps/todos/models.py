import uuid
from django.db import models
from django.conf import settings


class TodoList(models.Model):
    """
    A container of to-do items inside a project.
    Has a hill chart progress value.
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project     = models.ForeignKey('projects.Project', on_delete=models.CASCADE, related_name='todo_lists')
    name        = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    # Hill chart: 0 = figuring out, 50 = at the top, 100 = done
    hill_progress = models.PositiveIntegerField(default=0)
    created_by  = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    created_at  = models.DateTimeField(auto_now_add=True)
    position    = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = 'todo_lists'
        ordering = ['position', 'created_at']

    def __str__(self):
        return f"{self.project.name} → {self.name}"

    @property
    def completion_percentage(self):
        total = self.todos.count()
        if total == 0:
            return 0
        done = self.todos.filter(is_completed=True).count()
        return round((done / total) * 100)


class TodoItem(models.Model):
    """
    A single to-do task. Can be assigned, have due dates,
    priority, subtasks, and rich description.
    """

    class Priority(models.TextChoices):
        LOW    = 'low',    'Low'
        NORMAL = 'normal', 'Normal'
        HIGH   = 'high',   'High'
        URGENT = 'urgent', 'Urgent'

    id           = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    todo_list    = models.ForeignKey(TodoList, on_delete=models.CASCADE, related_name='todos')
    parent       = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.CASCADE, related_name='subtasks'
    )
    title        = models.CharField(max_length=500)
    # Rich description — stores HTML from Tiptap editor on the frontend
    description  = models.TextField(blank=True)
    assigned_to  = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='assigned_todos'
    )
    created_by   = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='created_todos'
    )
    priority     = models.CharField(max_length=10, choices=Priority.choices, default=Priority.NORMAL)
    due_date     = models.DateField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    position     = models.PositiveIntegerField(default=0)
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'todo_items'
        ordering = ['position', 'created_at']

    def __str__(self):
        return self.title

    def reassign(self, new_user):
        """Transfer this to-do to another user (SRS section 6)"""
        self.assigned_to = new_user
        self.save(update_fields=['assigned_to', 'updated_at'])
