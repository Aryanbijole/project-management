import uuid
from django.db import models
from django.conf import settings


class Project(models.Model):
    """A project inside an organization"""

    class Visibility(models.TextChoices):
        PUBLIC   = 'public',   'Everyone in org'
        PRIVATE  = 'private',  'Only invited members'

    id           = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name         = models.CharField(max_length=255)
    description  = models.TextField(blank=True)
    organization = models.ForeignKey(
        'organizations.Organization', on_delete=models.CASCADE, related_name='projects'
    )
    owner        = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='owned_projects'
    )
    visibility   = models.CharField(max_length=20, choices=Visibility.choices, default=Visibility.PUBLIC)
    color        = models.CharField(max_length=7, default='#4F46E5')  # hex color
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)
    is_archived  = models.BooleanField(default=False)

    class Meta:
        db_table = 'projects'
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class ProjectMember(models.Model):
    """Many-to-many: who has access to which project"""

    class Role(models.TextChoices):
        ADMIN      = 'admin',      'Admin'
        MEMBER     = 'member',     'Member'
        CLIENT     = 'client',     'Client'
        VIEWER     = 'viewer',     'Viewer'

    project    = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='memberships')
    user       = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='project_memberships')
    role       = models.CharField(max_length=20, choices=Role.choices, default=Role.MEMBER)
    joined_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'project_members'
        unique_together = ['project', 'user']

    def __str__(self):
        return f"{self.user.email} → {self.project.name} ({self.role})"


class ProjectTool(models.Model):
    """
    Which tools are enabled/disabled per project.
    Tools: todos, messages, card_table, chat, etc.
    Admins can rename tools at org level (names apply to new projects only).
    """

    class ToolType(models.TextChoices):
        TODOS        = 'todos',        'To-do Lists'
        MESSAGES     = 'messages',     'Message Board'
        CARD_TABLE   = 'card_table',   'Card Table'
        CHAT         = 'chat',         'Chat'
        DOCS         = 'docs',         'Docs'
        SCHEDULE     = 'schedule',     'Schedule'

    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project    = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='tools')
    tool_type  = models.CharField(max_length=30, choices=ToolType.choices)
    name       = models.CharField(max_length=100)  # Custom name (e.g. "Tasks" instead of "To-dos")
    is_enabled = models.BooleanField(default=True)
    position   = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = 'project_tools'
        unique_together = ['project', 'tool_type']
        ordering = ['position']

    def __str__(self):
        return f"{self.project.name} → {self.name}"
