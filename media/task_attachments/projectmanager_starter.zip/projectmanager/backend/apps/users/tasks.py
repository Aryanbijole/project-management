from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings


@shared_task
def send_invite_email(invitation_id):
    """
    Background task: sends invite email after admin invites someone.
    Triggered by InviteUserView. Runs via Celery worker.
    """
    from .models import Invitation

    try:
        invitation = Invitation.objects.select_related('invited_by').get(id=invitation_id)
    except Invitation.DoesNotExist:
        return

    invite_link = f"http://localhost:5173/accept-invite?token={invitation.token}"
    invited_by_name = invitation.invited_by.get_full_name() or invitation.invited_by.email

    send_mail(
        subject=f"You've been invited to Project Manager by {invited_by_name}",
        message=f"""
Hi,

{invited_by_name} has invited you to join Project Manager as a {invitation.role}.

Click the link below to accept the invitation and set your password:
{invite_link}

This link expires in 7 days.

— Project Manager Team
        """.strip(),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[invitation.email],
        fail_silently=False,
    )
