from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Invitation

User = get_user_model()


# ── User Serializers ──────────────────────────────────────────

class UserSerializer(serializers.ModelSerializer):
    """Used for reading user data"""
    class Meta:
        model  = User
        fields = ['id', 'email', 'username', 'first_name', 'last_name',
                  'role', 'avatar', 'bio', 'is_online', 'date_joined']
        read_only_fields = ['id', 'date_joined', 'is_online']


class RegisterSerializer(serializers.ModelSerializer):
    """Used for creating a new user account"""
    password  = serializers.CharField(write_only=True, min_length=8)
    password2 = serializers.CharField(write_only=True, label='Confirm password')

    class Meta:
        model  = User
        fields = ['email', 'username', 'first_name', 'last_name', 'password', 'password2']

    def validate(self, data):
        if data['password'] != data['password2']:
            raise serializers.ValidationError({'password2': 'Passwords do not match.'})
        return data

    def create(self, validated_data):
        validated_data.pop('password2')
        return User.objects.create_user(**validated_data)


class UpdateProfileSerializer(serializers.ModelSerializer):
    """Used by the user to update their own profile"""
    class Meta:
        model  = User
        fields = ['first_name', 'last_name', 'bio', 'avatar', 'timezone']


class InvitationSerializer(serializers.ModelSerializer):
    invited_by = UserSerializer(read_only=True)

    class Meta:
        model  = Invitation
        fields = ['id', 'email', 'role', 'status', 'invited_by', 'created_at', 'expires_at']
        read_only_fields = ['id', 'invited_by', 'status', 'created_at', 'expires_at', 'token']
