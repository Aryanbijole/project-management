from django.urls import path
from . import views

urlpatterns = [
    path('register/',          views.RegisterView.as_view(),       name='user-register'),
    path('me/',                views.ProfileView.as_view(),         name='user-profile'),
    path('',                   views.UserListView.as_view(),        name='user-list'),
    path('invite/',            views.InviteUserView.as_view(),      name='user-invite'),
    path('invite/accept/',     views.AcceptInviteView.as_view(),    name='invite-accept'),
    path('<uuid:pk>/role/',    views.UpdateUserRoleView.as_view(),  name='user-role'),
]
