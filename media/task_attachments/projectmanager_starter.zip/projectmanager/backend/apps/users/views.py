from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta
import uuid

from .models import Invitation
from .serializers import (
    UserSerializer, RegisterSerializer,
    UpdateProfileSerializer, InvitationSerializer
)

User = get_user_model()


class RegisterView(generics.CreateAPIView):
    """
    POST /api/users/register/
    Create a new user account.
    """
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]


class ProfileView(generics.RetrieveUpdateAPIView):
    """
    GET  /api/users/me/         → get my profile
    PATCH /api/users/me/        → update my profile
    """
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user

    def get_serializer_class(self):
        if self.request.method in ['PUT', 'PATCH']:
            return UpdateProfileSerializer
        return UserSerializer


class UserListView(generics.ListAPIView):
    """
    GET /api/users/
    List all users in the system. Admin only.
    """
    serializer_class   = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return User.objects.all().order_by('first_name')


class InviteUserView(APIView):
    """
    POST /api/users/invite/
    Admin invites someone by email. Sends an invite email with a token link.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        email = request.data.get('email')
        role  = request.data.get('role', 'member')

        if not email:
            return Response({'error': 'Email is required.'}, status=400)

        if User.objects.filter(email=email).exists():
            return Response({'error': 'User with this email already exists.'}, status=400)

        invitation = Invitation.objects.create(
            email      = email,
            invited_by = request.user,
            role       = role,
            expires_at = timezone.now() + timedelta(days=7),
        )

        # Send the invite email
        from .tasks import send_invite_email
        send_invite_email.delay(invitation.id)

        return Response(
            InvitationSerializer(invitation).data,
            status=status.HTTP_201_CREATED
        )


class AcceptInviteView(APIView):
    """
    POST /api/users/invite/accept/
    New user accepts invite and sets their password.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        token    = request.data.get('token')
        password = request.data.get('password')

        try:
            invitation = Invitation.objects.get(token=token, status='pending')
        except Invitation.DoesNotExist:
            return Response({'error': 'Invalid or expired invite link.'}, status=400)

        if invitation.expires_at < timezone.now():
            invitation.status = 'expired'
            invitation.save()
            return Response({'error': 'This invite link has expired.'}, status=400)

        # Create the user account
        user = User.objects.create_user(
            email    = invitation.email,
            username = invitation.email.split('@')[0],
            password = password,
            role     = invitation.role,
        )

        invitation.status = 'accepted'
        invitation.save()

        return Response(UserSerializer(user).data, status=201)


class UpdateUserRoleView(APIView):
    """
    PATCH /api/users/<id>/role/
    Admin changes a user's role.
    """
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        if not request.user.is_admin_or_owner:
            return Response({'error': 'Permission denied.'}, status=403)

        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'error': 'User not found.'}, status=404)

        new_role = request.data.get('role')
        if new_role not in [r[0] for r in User.Role.choices]:
            return Response({'error': 'Invalid role.'}, status=400)

        user.role = new_role
        user.save()
        return Response(UserSerializer(user).data)
