import uuid
from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Custom user model. Extends Django's built-in user
    with roles and profile fields needed for the SRS.
    """

    class Role(models.TextChoices):
        OWNER               = 'owner',               'Owner'
        ADMIN               = 'admin',               'Admin'
        MEMBER              = 'member',               'Member'
        CLIENT              = 'client',              'Client'
        OUTSIDE_COLLABORATOR = 'outside_collaborator', 'Outside Collaborator'

    id        = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email     = models.EmailField(unique=True)
    role      = models.CharField(max_length=30, choices=Role.choices, default=Role.MEMBER)
    avatar    = models.ImageField(upload_to='avatars/', null=True, blank=True)
    bio       = models.TextField(blank=True)
    is_online = models.BooleanField(default=False)
    timezone  = models.CharField(max_length=50, default='Asia/Kolkata')

    # When an account is merged into another, point here
    merged_into = models.ForeignKey(
        'self', null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='merged_accounts'
    )

    USERNAME_FIELD  = 'email'
    REQUIRED_FIELDS = ['username']

    class Meta:
        db_table = 'users'

    def __str__(self):
        return f"{self.get_full_name() or self.email} ({self.role})"

    @property
    def is_admin_or_owner(self):
        return self.role in [self.Role.ADMIN, self.Role.OWNER]


class Invitation(models.Model):
    """
    Tracks pending invites sent to new users.
    When they click the email link, they land on a signup page.
    """

    class Status(models.TextChoices):
        PENDING  = 'pending',  'Pending'
        ACCEPTED = 'accepted', 'Accepted'
        EXPIRED  = 'expired',  'Expired'

    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email      = models.EmailField()
    invited_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_invitations')
    token      = models.UUIDField(default=uuid.uuid4, unique=True)
    role       = models.CharField(max_length=30, choices=User.Role.choices, default=User.Role.MEMBER)
    status     = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    class Meta:
        db_table = 'invitations'

    def __str__(self):
        return f"Invite to {self.email} ({self.status})"
