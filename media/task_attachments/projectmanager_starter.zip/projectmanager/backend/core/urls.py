from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerUIView

urlpatterns = [

    # ── Django Admin ──────────────────────────────────────────
    path('admin/', admin.site.urls),

    # ── Auth (JWT Login / Refresh) ────────────────────────────
    path('api/auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # ── App APIs ──────────────────────────────────────────────
    path('api/users/',         include('apps.users.urls')),
    path('api/organizations/', include('apps.organizations.urls')),
    path('api/projects/',      include('apps.projects.urls')),
    path('api/todos/',         include('apps.todos.urls')),
    path('api/messages/',      include('apps.messages_board.urls')),
    path('api/chat/',          include('apps.chat.urls')),
    path('api/exports/',       include('apps.exports.urls')),

    # ── API Docs (Swagger UI at /api/docs/) ───────────────────
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/',   SpectacularSwaggerUIView.as_view(url_name='schema'), name='swagger-ui'),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    import debug_toolbar
    urlpatterns = [path('__debug__/', include(debug_toolbar.urls))] + urlpatterns
