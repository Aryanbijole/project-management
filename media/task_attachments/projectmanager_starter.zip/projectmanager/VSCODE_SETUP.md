# VS Code Extensions to Install

Open VS Code → Press Ctrl+Shift+X → Search each name → Click Install

## Essential Extensions

| Extension Name               | Publisher       | What it does                          |
|------------------------------|-----------------|---------------------------------------|
| Python                       | Microsoft       | Python language support, IntelliSense |
| Pylance                      | Microsoft       | Faster Python type checking           |
| Django                       | Baptiste Dartry | Django template support               |
| ES7+ React/Redux Snippets    | dsznajder       | React code shortcuts                  |
| Tailwind CSS IntelliSense    | Tailwind Labs   | Autocomplete Tailwind classes         |
| Prettier                     | Prettier        | Auto-format JS/HTML/CSS               |
| ESLint                       | Microsoft       | Catch JS errors                       |
| Thunder Client               | Thunder Client  | Test your Django API (like Postman)   |
| GitLens                      | GitKraken       | Better Git history in VS Code         |
| Docker                       | Microsoft       | Manage Docker containers              |
| DotENV                       | mikestead       | Syntax highlight .env files           |
| GitHub Copilot               | GitHub          | AI code autocomplete (sign up free)   |

## VS Code Settings (add to settings.json)

Press Ctrl+Shift+P → "Open User Settings JSON" → paste this:

```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "[python]": {
    "editor.defaultFormatter": "ms-python.python"
  },
  "python.linting.enabled": true,
  "emmet.includeLanguages": {
    "django-html": "html"
  }
}
```
