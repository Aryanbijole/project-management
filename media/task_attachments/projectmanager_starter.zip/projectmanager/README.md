# Project Manager

A full-stack project management tool (Basecamp/ClickUp style)  
Built with Django + React for internship project.

---

## Tech Stack

| Layer         | Technology                       |
|---------------|----------------------------------|
| Frontend      | React + Tailwind CSS + Vite      |
| Backend       | Django + Django REST Framework   |
| Database      | PostgreSQL                       |
| Real-time     | Django Channels + Redis          |
| Background    | Celery + Redis                   |
| Auth          | JWT (SimpleJWT)                  |
| File Storage  | Local (dev) / AWS S3 (prod)      |
| Deploy        | Docker + Railway / Render        |

---

## Project Structure

```
projectmanager/
├── backend/
│   ├── core/               ← Django project (settings, urls, asgi)
│   ├── apps/
│   │   ├── users/          ← Auth, invite, roles
│   │   ├── organizations/  ← Orgs, groups, companies
│   │   ├── projects/       ← Projects, tools config
│   │   ├── todos/          ← To-do lists and items
│   │   ├── messages_board/ ← Message board
│   │   ├── chat/           ← WebSocket real-time chat
│   │   └── exports/        ← Data export
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/               ← React app (create with Vite)
├── docker-compose.yml
├── setup.sh
└── README.md
```

---

## First-Time Setup

### Prerequisites — install these first:

1. **Python 3.12** → https://python.org/downloads
2. **Node.js 20** → https://nodejs.org
3. **Docker Desktop** → https://docker.com/products/docker-desktop
4. **VS Code** → https://code.visualstudio.com
5. **Git** → https://git-scm.com

### Run setup:

```bash
# 1. Clone/open the project in VS Code terminal
bash setup.sh

# 2. Start database and Redis
docker compose up db redis -d

# 3. Run migrations
cd backend
source venv/bin/activate        # Windows: venv\Scripts\activate
python manage.py migrate
python manage.py createsuperuser

# 4. Start Django backend
python manage.py runserver

# 5. In a NEW terminal tab — start React
cd frontend
npm run dev
```

---

## Key URLs

| URL                              | What it is                          |
|----------------------------------|-------------------------------------|
| http://localhost:5173            | React frontend (your app)           |
| http://localhost:8000/admin/     | Django admin panel                  |
| http://localhost:8000/api/docs/  | Auto-generated API docs (Swagger)   |
| http://localhost:8000/api/users/ | Users API                           |

---

## Daily Development Commands

```bash
# Make new migration after changing a model
python manage.py makemigrations
python manage.py migrate

# Create a new Django app
python manage.py startapp appname
mv appname apps/appname

# Run tests
python manage.py test

# Start Celery worker (for emails/exports)
celery -A core worker --loglevel=info

# Django shell (test queries)
python manage.py shell
```

---

## API Endpoints

### Auth
| Method | URL                          | What it does        |
|--------|------------------------------|---------------------|
| POST   | /api/auth/login/             | Login → get JWT     |
| POST   | /api/auth/refresh/           | Refresh JWT token   |
| POST   | /api/users/register/         | Register new user   |
| POST   | /api/users/invite/           | Admin invites user  |
| POST   | /api/users/invite/accept/    | Accept invite       |

### Projects
| Method | URL                          | What it does        |
|--------|------------------------------|---------------------|
| GET    | /api/projects/               | List projects       |
| POST   | /api/projects/               | Create project      |
| GET    | /api/projects/<id>/          | Get project detail  |
| PATCH  | /api/projects/<id>/          | Update project      |

### To-dos
| Method | URL                          | What it does        |
|--------|------------------------------|---------------------|
| GET    | /api/todos/lists/            | List all todo lists |
| POST   | /api/todos/lists/            | Create a list       |
| GET    | /api/todos/items/            | Get todo items      |
| POST   | /api/todos/items/            | Create a todo       |
| PATCH  | /api/todos/items/<id>/       | Update/complete     |

---

## WebSocket (Chat)

```javascript
// Connect from React frontend
const socket = new WebSocket('ws://localhost:8000/ws/chat/project/<project_id>/');

socket.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log(data); // { type: 'message', message, user_name, timestamp }
};

socket.send(JSON.stringify({ message: 'Hello!' }));
```
