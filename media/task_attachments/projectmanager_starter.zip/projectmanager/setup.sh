#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  PROJECT MANAGER - ONE-TIME SETUP SCRIPT
#  Run this once after cloning the project.
#  Usage:  bash setup.sh
# ─────────────────────────────────────────────────────────────

set -e  # Stop if any command fails

echo ""
echo "═══════════════════════════════════════════"
echo "  Project Manager - Setting up..."
echo "═══════════════════════════════════════════"
echo ""

# ── 1. Check Python ──────────────────────────────────────────
echo "▶ Checking Python..."
python3 --version || { echo "ERROR: Python 3 not found. Install from https://python.org"; exit 1; }

# ── 2. Check Node.js ─────────────────────────────────────────
echo "▶ Checking Node.js..."
node --version || { echo "ERROR: Node.js not found. Install from https://nodejs.org"; exit 1; }

# ── 3. Backend setup ─────────────────────────────────────────
echo ""
echo "▶ Setting up Django backend..."
cd backend

python3 -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate

pip install --upgrade pip
pip install -r requirements.txt

# Copy .env if it doesn't exist
if [ ! -f .env ]; then
    cp .env.example .env
    echo "  ✓ Created .env — edit it with your DB credentials"
fi

cd ..

# ── 4. Frontend setup ────────────────────────────────────────
echo ""
echo "▶ Setting up React frontend..."
cd frontend

npm install

cd ..

# ── 5. Done ──────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════"
echo "  ✓ Setup complete!"
echo "═══════════════════════════════════════════"
echo ""
echo "  Next steps:"
echo ""
echo "  1. Start PostgreSQL and Redis:"
echo "     docker compose up db redis -d"
echo ""
echo "  2. Run Django migrations:"
echo "     cd backend && source venv/bin/activate"
echo "     python manage.py migrate"
echo "     python manage.py createsuperuser"
echo ""
echo "  3. Start the backend:"
echo "     python manage.py runserver"
echo ""
echo "  4. In a new terminal, start the frontend:"
echo "     cd frontend && npm run dev"
echo ""
echo "  Open http://localhost:5173 in your browser"
echo "  Django admin: http://localhost:8000/admin"
echo "  API docs:     http://localhost:8000/api/docs/"
echo ""
